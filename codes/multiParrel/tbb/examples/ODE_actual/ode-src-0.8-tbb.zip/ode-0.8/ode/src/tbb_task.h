/*************************************************************************
 *                                                                       *
 *  Copyright 2007 Intel Corporation. All Rights Reserved.               *
 *                                                                       *
 *************************************************************************/

#ifndef __TBB_STEPPER
#define __TBB_STEPPER

#include "tbb_common.h"

class process_world;
void dInternalStepIslandFast (dxWorld * world, dxBody * const *bodies, int nb, dxJoint * const *_joints, int nj, dReal stepsize, int maxiterations);
void processIslandsFast (process_world& tbb_root, dxWorld * world, dReal stepsize, int maxiterations);

const int GrainSize = 5;

typedef struct 
{
	dxWorld * world;
	dxBody * const *bodies;
	dxJoint * const *joints;
	dReal stepsize;
	int maxiterations;
	int nb;
	int nj;
} context_t;

class process_one_island: public tbb::task
{
	context_t *p;
public:
	process_one_island (context_t *params): p (params) {}
	task* execute ()
	{
		dInternalStepIslandFast (p->world, p->bodies, p->nb, p->joints, p->nj, p->stepsize, p->maxiterations);
		return NULL;
	}
};

class process_world: public tbb::task
{
	dxWorld * world; dReal stepsize; int maxiterations;
public:
	process_world (dxWorld * _world, dReal _stepsize, int _maxiterations) :  world(_world), stepsize(_stepsize), maxiterations(_maxiterations){}
	task* execute ()
	{
		processIslandsFast (*this, world, stepsize, maxiterations);
		return NULL;
	}
};

#endif // __TBB_STEPPER
