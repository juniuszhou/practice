/*************************************************************************
 *                                                                       *
 *  Copyright 2007 Intel Corporation. All Rights Reserved.               *
 *                                                                       *
 *************************************************************************/

#ifndef __TBB_PFOR
#define __TBB_PFOR

#include "tbb_common.h"

void dInternalStepIslandFast (dxWorld * world, dxBody * const *bodies, int nb, 
							  dxJoint * const *_joints, int nj, dReal stepsize, int maxiterations);

const int GrainSize = 5;

typedef struct 
{
	dxWorld * world;
	dxBody * const *bodies;
	dxJoint * const *joints;
	dReal stepsize;
	int maxiterations;
	int nb;
	int nj;
} context_t;

typedef std::vector<context_t*> islands_vector;

class process_islands
{
	islands_vector &p;
public:
	process_islands (islands_vector& params): p (params) {}
	void operator() (tbb::blocked_range<int> &r) const
	{
		for (int i = r.begin(); i != r.end(); i++)
			dInternalStepIslandFast (p[i]->world, p[i]->bodies, p[i]->nb, p[i]->joints, 
									 p[i]->nj, p[i]->stepsize, p[i]->maxiterations);
	}
};

#endif // __TBB_PFOR
