/*************************************************************************
 *                                                                       *
 *  Copyright 2007 Intel Corporation. All Rights Reserved.               *
 *                                                                       *
 *************************************************************************/

#ifndef __TBB_COMMON
#define __TBB_COMMON

#include "tbb/task_scheduler_init.h"
#include "tbb/task.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"

#include <vector>

#endif // __TBB_COMMON
