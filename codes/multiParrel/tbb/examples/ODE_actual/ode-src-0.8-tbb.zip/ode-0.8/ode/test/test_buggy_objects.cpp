/*************************************************************************
 *                                                                       *
 *  Copyright 2007 Intel Corporation. All Rights Reserved.               *
 *                                                                       *
 *************************************************************************/

/*************************************************************************
 *                                                                       *
 * Open Dynamics Engine, Copyright (C) 2001,2002 Russell L. Smith.       *
 * All rights reserved.  Email: russ@q12.org   Web: www.q12.org          *
 *                                                                       *
 * This library is free software; you can redistribute it and/or         *
 * modify it under the terms of EITHER:                                  *
 *   (1) The GNU Lesser General Public License as published by the Free  *
 *       Software Foundation; either version 2.1 of the License, or (at  *
 *       your option) any later version. The text of the GNU Lesser      *
 *       General Public License is included with this library in the     *
 *       file LICENSE.TXT.                                               *
 *   (2) The BSD-style license that is included with this library in     *
 *       the file LICENSE-BSD.TXT.                                       *
 *                                                                       *
 * This library is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the files    *
 * LICENSE.TXT and LICENSE-BSD.TXT for more details.                     *
 *                                                                       *
 *************************************************************************/

/*

buggy with suspension.
this also shows you how to use geom groups.

*/
#include <iostream>

#include <ode/ode.h>
#include <drawstuff/drawstuff.h>

using namespace std;

#ifdef _MSC_VER
#pragma warning(disable:4244 4305)  // for VC++, no precision loss complaints
#endif

// select correct drawing functions

#ifdef dDOUBLE
#define dsDrawBox dsDrawBoxD
#define dsDrawSphere dsDrawSphereD
#define dsDrawCylinder dsDrawCylinderD
#define dsDrawCapsule dsDrawCapsuleD
#endif


// some constants

#define LENGTH 0.7	// chassis length
#define WIDTH 0.5	// chassis width
#define HEIGHT 0.2	// chassis height
#define RADIUS 0.18	// wheel radius
#define STARTZ 0.5	// starting height of chassis
#define CMASS 1		// chassis mass
#define WMASS 0.2	// wheel mass
#define CHAIN_LEN 10 // number of boxes in attached chain

struct car {
	dReal speed,steer;
	dBodyID body[4+CHAIN_LEN];
	dJointID joint[3];	// joint[0] is the front wheel
	dGeomID box[1];
	dGeomID sphere[3];
	dGeomID chain_box[CHAIN_LEN];
	dJointID chain_joint[CHAIN_LEN];
};

static int num_sim_threads = 1;
static unsigned int gNumObjects = 64; // target number of objects

// dynamics and collision objects (chassis, 3 wheels, environment)
#define MAXCARS 256

static dWorldID world;
static dSpaceID space;
static dJointGroupID contactgroup;
static dGeomID ground;
static dGeomID ground_box = 0;
static car* cars[MAXCARS];
static intP numCars = 0;

// car 0 is user controlled through gSpeed and gSteer
static dReal gSpeed=2,gSteer=0.75;

// Remove a car object from the collision space
void destroyCar( intP num)
{
  if(num >= numCars)
	  return;

  numCars--;
  car* nextCar = cars[num];

  free(cars[num]);
  cars[num] = 0;

  for(intP i=num+1; i<numCars; i++)
  {
    dGeomSetData (cars[i]->box[0], (int*)i);
    dGeomSetData (cars[i]->sphere[0], (int*)i);
    dGeomSetData (cars[i]->sphere[1], (int*)i);
    dGeomSetData (cars[i]->sphere[2], (int*)i);
	cars[i-1] = cars[i];
  }
}

// Add a car object to the collision space
void createCar(float posx, float posy, float posz, float initSpeed, float initSteer)
{
  if(numCars+1 >= MAXCARS)
	  return;

  dMass m;
  int i;

  cars[numCars] = (car*) malloc(sizeof(car));
  car* nextCar  = cars[numCars];

  numCars++;

  nextCar->speed = initSpeed;
  nextCar->steer = initSteer;

  // chassis body
  nextCar->body[0] = dBodyCreate (world);
  dBodySetPosition (nextCar->body[0],posx,posy,posz);
  dMassSetBox (&m,1,LENGTH,WIDTH,HEIGHT);
  dMassAdjust (&m,CMASS);
  dBodySetMass (nextCar->body[0],&m);
  nextCar->box[0] = dCreateBox (0,LENGTH,WIDTH,HEIGHT);
  dGeomSetBody (nextCar->box[0],nextCar->body[0]);

  // wheel bodies
  for (i=1; i<=3; i++) {
    nextCar->body[i] = dBodyCreate (world);
    dQuaternion q;
    dQFromAxisAndAngle (q,1,0,0,M_PI*0.5);
    dBodySetQuaternion (nextCar->body[i],q);
    dMassSetSphere (&m,1,RADIUS);
    dMassAdjust (&m,WMASS);
    dBodySetMass (nextCar->body[i],&m);
    nextCar->sphere[i-1] = dCreateSphere (0,RADIUS);
    dGeomSetBody (nextCar->sphere[i-1],nextCar->body[i]);
  }
  dBodySetPosition (nextCar->body[1],posx+0.5*LENGTH,posy,posz-HEIGHT*0.5);
  dBodySetPosition (nextCar->body[2],posx-0.5*LENGTH, posy+WIDTH*0.5,posz-HEIGHT*0.5);
  dBodySetPosition (nextCar->body[3],posx-0.5*LENGTH,posy-WIDTH*0.5,posz-HEIGHT*0.5);

  // front wheel hinge
  /*
  joint[0] = dJointCreateHinge2 (world,0);
  dJointAttach (joint[0],body[0],body[1]);
  const dReal *a = dBodyGetPosition (body[1]);
  dJointSetHinge2Anchor (joint[0],a[0],a[1],a[2]);
  dJointSetHinge2Axis1 (joint[0],0,0,1);
  dJointSetHinge2Axis2 (joint[0],0,1,0);
  */

  // front and back wheel hinges
  for (i=0; i<3; i++) {
    nextCar->joint[i] = dJointCreateHinge2 (world,0);
    dJointAttach (nextCar->joint[i],nextCar->body[0],nextCar->body[i+1]);
    const dReal *a = dBodyGetPosition (nextCar->body[i+1]);
    dJointSetHinge2Anchor (nextCar->joint[i],a[0],a[1],a[2]);
    dJointSetHinge2Axis1 (nextCar->joint[i],0,0,1);
    dJointSetHinge2Axis2 (nextCar->joint[i],0,1,0);
  }

  // set joint suspension
  for (i=0; i<3; i++) {
    dJointSetHinge2Param (nextCar->joint[i],dParamSuspensionERP,0.4);
    dJointSetHinge2Param (nextCar->joint[i],dParamSuspensionCFM,0.8);
  }

  // lock back wheels along the steering axis
  for (i=1; i<3; i++) {
    // set stops to make sure wheels always stay in alignment
    dJointSetHinge2Param (nextCar->joint[i],dParamLoStop,0);
    dJointSetHinge2Param (nextCar->joint[i],dParamHiStop,0);
  }

  // create a chain of boxes and attach to car body
#define BOX_SIDE 0.1

  for (i=0; i<CHAIN_LEN; i++) 
  {
    dReal k = i*BOX_SIDE;

	nextCar->body[i+4] = dBodyCreate (world);
    dBodySetPosition (nextCar->body[i+4],posx-(k+0.5*LENGTH), posy,posz-HEIGHT*0.5);
    dMassSetBox (&m,1,BOX_SIDE,BOX_SIDE,BOX_SIDE);
    dBodySetMass (nextCar->body[i+4],&m);
    nextCar->chain_box[i] = dCreateBox (0,BOX_SIDE,BOX_SIDE,BOX_SIDE);
    dGeomSetBody (nextCar->chain_box[i],nextCar->body[i+4]);
  }

  for (i=0; i<CHAIN_LEN; i++) {
	nextCar->chain_joint[i] = dJointCreateBall (world,0);
	if(i==0)
	{
      dJointAttach (nextCar->chain_joint[i],nextCar->body[4],nextCar->body[0]);
	}
	else
	{
      dJointAttach (nextCar->chain_joint[i],nextCar->body[i+4],nextCar->body[i+3]);
	}

	dReal kk = (i+0.5)*BOX_SIDE;
	dJointSetBallAnchor (nextCar->chain_joint[i], posx-(kk+0.5*LENGTH), posy,posz-HEIGHT*0.5);
  }

  dGeomSetData(nextCar->box[0], (int*)numCars);
  dGeomSetData(nextCar->sphere[0], (int*)numCars);
  dGeomSetData(nextCar->sphere[1], (int*)numCars);
  dGeomSetData(nextCar->sphere[2], (int*)numCars);
  dSpaceAdd (space,nextCar->box[0]);
  dSpaceAdd (space,nextCar->sphere[0]);
  dSpaceAdd (space,nextCar->sphere[1]);
  dSpaceAdd (space,nextCar->sphere[2]);

  for (i=0; i<CHAIN_LEN; i++)
  {
	  dGeomSetData(nextCar->chain_box[i], (int*)numCars);
	  dSpaceAdd (space,nextCar->chain_box[i]);
  }
}


// this is called by dSpaceCollide when two objects in space are
// potentially colliding.

static void nearCallback (void *data, dGeomID o1, dGeomID o2)
{
  int i,n;

  const int N = 10;
  dContact contact[N];
  n = dCollide (o1,o2,N,&contact[0].geom,sizeof(dContact));
  if (n > 0) {
    for (i=0; i<n; i++) {
	  int* userData1 = (int*) dGeomGetData(contact[i].geom.g1);
	  int* userData2 = (int*) dGeomGetData(contact[i].geom.g2);

	  if(userData1 == userData2)
		  continue;

      contact[i].surface.mode = dContactSlip1 | dContactSlip2 |
	  dContactSoftERP | dContactSoftCFM | dContactApprox1;
      contact[i].surface.mu = dInfinity;
      contact[i].surface.slip1 = 0.1;
      contact[i].surface.slip2 = 0.1;
      contact[i].surface.soft_erp = 0.5;
      contact[i].surface.soft_cfm = 0.3;
      dJointID c = dJointCreateContact (world,contactgroup,&contact[i]);
      dJointAttach (c,
		    dGeomGetBody(contact[i].geom.g1),
		    dGeomGetBody(contact[i].geom.g2));
    }
  }
}


// start simulation - set viewpoint

static void start()
{
  static float xyz[3] = {1.8317f,-1.9817f,1.8000f};
  static float hpr[3] = {65.0000f,-27.5000f,0.0000f};
  dsSetViewpoint (xyz,hpr);

  printf ("\nODE Multithreaded\n\n");

  printf ("Press:\t'a' to increase speed.\n"
	  "\t'z' to decrease speed.\n"
	  "\t',' to steer left.\n"
	  "\t'.' to steer right.\n"
	  "\t' ' to reset speed and steering.\n"
/*	  "\t's' to save the current state to 'state.dif'.\n"*/);
}


// called when a key pressed

static void command (int cmd)
{
  if (cmd >= '0' && cmd <= '6') 
  {
    num_sim_threads = 1 << (cmd - '0');
	if(num_sim_threads == 1) printf("%d simulation thread\n", num_sim_threads);
	else printf("%d simulation threads\n", num_sim_threads);
  }
  else
  {
	  switch (cmd) {
	  case 'a': case 'A':
	    gSpeed += 0.3;
	    break;
	  case 'z': case 'Z':
	    gSpeed -= 0.3;
	    break;
	  case ',':
	    gSteer -= 0.5;
		gSteer = gSteer < -1.0 ? -1.0 : gSteer;
	    break;
	  case '.':
	    gSteer += 0.5;
		gSteer = gSteer > 1.0 ? 1.0 : gSteer;
	    break;
	  case ' ':
	    gSpeed = 0;
	    gSteer = 0;
	    break;
	  case 's': {
	      FILE *f = fopen ("state.dif","wt");
	      if (f) {
	        dWorldExportDIF (world,f,"");
	        fclose (f);
	      }
	    }
	}
  }
}


// simulation loop

static void simLoop (int pause)
{
  int i;
  if (!pause) {

    for(intP n=0; n<numCars; n++)
    {
  	  car* nextCar = cars[n];
	  float speed = n == 0 ? gSpeed : nextCar->speed;
	  float steer = n == 0 ? gSteer : nextCar->steer;

      // motor
      dJointSetHinge2Param (nextCar->joint[0],dParamVel2,-speed);
      dJointSetHinge2Param (nextCar->joint[0],dParamFMax2,0.1);

      // steering
      dReal v = steer - dJointGetHinge2Angle1 (nextCar->joint[0]);
      if (v > 0.1) v = 0.1;
      if (v < -0.1) v = -0.1;
      v *= 10.0;
      dJointSetHinge2Param (nextCar->joint[0],dParamVel,v);
      dJointSetHinge2Param (nextCar->joint[0],dParamFMax,0.2);
      dJointSetHinge2Param (nextCar->joint[0],dParamLoStop,-0.75);
      dJointSetHinge2Param (nextCar->joint[0],dParamHiStop,0.75);
      dJointSetHinge2Param (nextCar->joint[0],dParamFudgeFactor,0.1);
	}

    static int numIter = 1;

    for(int iter=0; iter<numIter; iter++)
    {
        double startCollideTime = 0;
	    double endCollideTime = 0;
	    double startStepTime = 0;
	    double endStepTime = 0;
		double endLoopTime = 0;

	    dSpaceCollide (space,0,&nearCallback);

	    //dWorldStep (world,0.05);
	    dWorldStepFast1 (world,0.1/(float)numIter, 5);

	    // remove all contact joints
	    dJointGroupEmpty (contactgroup);

		static int accumCnt2 = 0;
		static double totalCollideTime  = 0;
		static double totalResponseTime = 0;

	}
  }

  // draw the objects
  dsSetTexture (DS_WOOD);

  for(intP n=0; n<numCars; n++)
  {
    car* nextCar = cars[n];

	dReal sides[3] = {LENGTH,WIDTH,HEIGHT};

	if(n==0)
		dsSetColor (0,1,1);
	else
		dsSetColor (0,1,0);

	// draw the main car body
	dsDrawBox (dBodyGetPosition(nextCar->body[0]),dBodyGetRotation(nextCar->body[0]),sides);

	// draw the wheels
	dsSetColor (1,1,1);
    for (i=1; i<=3; i++) dsDrawCylinder (dBodyGetPosition(nextCar->body[i]),
  				         dBodyGetRotation(nextCar->body[i]),0.02f,RADIUS);

	// draw the chain of boxes
    dReal chain_box_sides[3] = {BOX_SIDE,BOX_SIDE,BOX_SIDE};
    dsSetColor (1,1,0);
    dsSetTexture (DS_WOOD);
    for (int i=0; i<CHAIN_LEN; i++)
      dsDrawBox (dBodyGetPosition(nextCar->body[i+4]),
	             dBodyGetRotation(nextCar->body[i+4]),
				 chain_box_sides);
  }

  dVector3 ss;
  dGeomBoxGetLengths (ground_box,ss);
  dsDrawBox (dGeomGetPosition(ground_box),dGeomGetRotation(ground_box),ss);
}

#ifdef __ITT_EVENTS
//	extern __itt_event proc_world_event;
#endif

int main (int argc, char **argv)
{
  // parse input arguments
  for (int i=1; i<argc; i++) 
  {
	if (strcmp(argv[i],"-numThreads")==0)
	{
		num_sim_threads = i < argc-1 ? atoi(argv[i+1]) : 1;
		if(num_sim_threads == 1) printf("%d simulation thread\n", num_sim_threads);
		else printf("%d simulation threads\n", num_sim_threads);
		i++;
	}
	else if (strcmp(argv[i],"-numObjects")==0)
	{
		gNumObjects = i < argc-1 ? atoi(argv[i+1]) : 1;
		i++;
	}
  }

  // setup pointers to drawstuff callback functions
  dsFunctions fn;
  fn.version = DS_VERSION;
  fn.start = &start;
  fn.step = &simLoop;
  fn.command = &command;
  fn.stop = 0;
  fn.path_to_textures = "../../drawstuff/textures";
  if(argc==2)
    {
        fn.path_to_textures = argv[1];
    }

  // create world
  dInitODE();
  world = dWorldCreate();
  space = dHashSpaceCreate (0);
  contactgroup = dJointGroupCreate (0);
  dWorldSetGravity (world,0,0,-0.5);
  ground = dCreatePlane (space,0,0,1,0);

#define MAXRANDNUMS 100
  static float randAngleSpeed[MAXRANDNUMS] = 
  {
	0.43, 0.38, 0.11, 0.30, 0.03, 0.97, 0.72, 0.55, 0.85, 0.52,
	0.58, 0.27, 0.42, 0.55, 0.76, 0.28, 0.40, 0.31, 0.18, 1.00,
	0.29, 0.61, 0.45, 0.55, 0.27, 0.92, 0.16, 0.55, 0.76, 0.64,
	0.77, 0.70, 0.48, 0.94, 0.88, 0.98, 0.30, 0.72, 0.02, 0.73,
	0.32, 0.83, 0.51, 0.56, 0.43, 0.55, 0.87, 0.23, 0.21, 0.77,
	0.10, 0.84, 0.34, 0.80,	0.79, 0.58, 0.27, 0.23, 0.54, 0.40,
	0.79, 0.27, 0.75, 0.46, 0.31, 0.21, 0.56, 0.18, 0.86, 0.53,
	0.78, 0.02, 0.35, 0.54, 0.48, 0.45, 0.95, 0.99, 0.21, 0.32,
	0.20, 0.44, 0.12, 0.72, 0.99, 0.10, 0.43, 0.06, 0.58, 0.29,
	0.88, 0.74, 0.02, 0.35, 0.95, 0.27, 0.59, 0.74, 0.23, 0.87
  };

#define MAXROWS 16
#define MAXCOLS 16

  int numRows = (int) sqrt((float)gNumObjects);
  int numCols = (int) gNumObjects/numRows;
  int numRemain = gNumObjects - numRows*numCols;

  int cnt = 0;
  int row, col;
  for(row=0; row<numRows; row++)
  {
    for(col=0; col<numCols; col++)
	{
	  float deltaPosx = randAngleSpeed[cnt++]-0.25;
	  float deltaPosy = randAngleSpeed[cnt++]-0.25;
	  float deltaPosz = randAngleSpeed[cnt++]+0.1;
	  float initSpeed      = 2 - 4*randAngleSpeed[cnt++];
	  float initSteerAngle = 1 - 2*randAngleSpeed[cnt++];
	  cnt %= 95;
	  createCar((row+deltaPosx)*2,(col+deltaPosy)*2,deltaPosz,initSpeed, initSteerAngle);
	}
  }

  for(col=0; col<numRemain; col++)
  {
    float deltaPosx = randAngleSpeed[cnt++]-0.25;
    float deltaPosy = randAngleSpeed[cnt++]-0.25;
    float deltaPosz = randAngleSpeed[cnt++]+0.1;
    float initSpeed      = 2 - 4*randAngleSpeed[cnt++];
    float initSteerAngle = 1 - 2*randAngleSpeed[cnt++];
    cnt %= 95;
    createCar((row+deltaPosx)*2,(col+deltaPosy)*2,deltaPosz,initSpeed, initSteerAngle);
  }

  // environment
  ground_box = dCreateBox (space,2,1.5,1);
  dMatrix3 R;
  dRFromAxisAndAngle (R,0,1,0,-0.15);
  dGeomSetPosition (ground_box,2,0,-0.34);
  dGeomSetRotation (ground_box,R);

  // run simulation
  dsSimulationLoop (argc,argv,352,288,&fn);

  dJointGroupDestroy (contactgroup);
  dSpaceDestroy (space);
  dWorldDestroy (world);
  dCloseODE();

  return 0;
}
